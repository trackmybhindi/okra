var schemas = {
    supplier: {
        supplier_id: null,
        supplier_name: null,
        supplier_address: null
    }
}

module.exports = schemas;